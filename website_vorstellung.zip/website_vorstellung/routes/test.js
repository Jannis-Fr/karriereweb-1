var express = require('express');
var router = express.Router();
var Stellenangebot=require('../models/stellenangebot');
var Stellentext=require('../models/stellentext');

/* GET home page. */
router.get('/', function(req, res, next) {
  let berufsfeld='614885daa9230e7dc525c2f9';
  let stellentext='614885daa9230e7dc525c309';

 
  Stellenangebot.find({$or:[{stellentext:stellentext},{berufsfeld:berufsfeld}]})
  
  
    //erweitere die suche mit dem dazugehörigen Ansprechpartner und dessen Standort
    
    //funktion mit dem such-array von oben als übergabeparameter.
    .exec(function (err, list_stellenangebote){
        //bei einem Error wird dieser Zurückgegeben
        if(err) {return next(err);}
        //Die sucharray liste wird zur /stellenangebot seite gesendet
        res.render('test', {stellenangebot_list: list_stellenangebote});
    });
});



module.exports = router;
