var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('fricke_social_day_abstimmung', { title: 'Fricke Social Day Abstimmung' });
});



module.exports = router;
