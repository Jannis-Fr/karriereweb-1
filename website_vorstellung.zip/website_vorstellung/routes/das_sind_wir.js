var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('das_sind_wir', { title: 'Das sind wir' });
});



module.exports = router;
