var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('fricke_azubi_infotag', { title: 'Fricke Azubi Infotag' });
});

module.exports = router;
