var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('fricke_sozial_day_abstimmung', { title: 'Fricke Sozial Day Abstimmung' });
});



module.exports = router;
