var express = require('express');
var router = express.Router();

//Stellenangebots controller wird angebunden
var stellenangebot_controller = require('../controllers/Controller_stellenangebot');


router.get('/',stellenangebot_controller.stellenangebot_list_get);

router.post('/',stellenangebot_controller.stellenangebot_list_post);

// GET request for one Book.
router.get('/:id', stellenangebot_controller.stellenangebot_detail);


module.exports = router;
