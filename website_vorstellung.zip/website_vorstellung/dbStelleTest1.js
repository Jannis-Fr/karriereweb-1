#! /usr/bin/env node

console.log('This script populates some test objekts to your database. Specified database as argument - e.g.: karrieredb mongodb+srv://cooluser:coolpassword@cluster0.a9azn.mongodb.net/local_library?retryWrites=true');

// Get arguments passed on command line
var userArgs = process.argv.slice(2);
/*
if (!userArgs[0].startsWith('mongodb')) {
    console.log('ERROR: You need to specify a valid mongodb URL as the first argument');
    return
}
*/
var async = require('async')
var Ansprechpartner = require('./models/ansprechpartner')
var Berufsfeld = require('./models/berufsfeld')
var Karrierelevel = require('./models/karrierelevel')
var Standort = require('./models/standort')
var Stelle = require('./models/stelle')
var Stellenangebot = require('./models/stellenangebot')
var Stellenbild = require('./models/stellenbild')
var Unternehmensbereich = require('./models/unternehmensbereich')


var mongoose = require('mongoose');
var mongoDB = userArgs[0];
mongoose.connect(mongoDB, {useNewUrlParser: true, useUnifiedTopology: true});
mongoose.Promise = global.Promise;
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

var ansprechpartnerarr = []
var berufsfeldarr = []
var karrierelevelarr = []
var standortarr = []
var stellearr = []
var stellenangebotarr = []
var stellenbildarr = []
var unternehmensbereicharr = []


//unternehmensbereich - - - - - - - - - - - -
function unternehmensbereichCreate(bezeichnung, homepage,beschreibung ,cb) {
  unternehmensbereichdetail = {bezeichnung:bezeichnung , beschreibung:beschreibung}
  if (homepage != false) unternehmensbereichdetail.homepage = homepage
 
  
  var unternehmensbereich = new Unternehmensbereich(unternehmensbereichdetail);
       
  unternehmensbereich.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New Unternehmensbereich: ' + unternehmensbereich);
    unternehmensbereicharr.push(unternehmensbereich)
    cb(null, unternehmensbereich)
  }  );
}



//berufsfeld - - - - - - - - - - - -
function berufsfeldCreate(bezeichnung, cb) {
  berufsfelddetail = {bezeichnung:bezeichnung } 
  
  var berufsfeld = new Berufsfeld(berufsfelddetail);
       
  berufsfeld.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New Berufsfeld: ' + berufsfeld);
    berufsfeldarr.push(berufsfeld)
    cb(null, berufsfeld)
  }  );
}


//karrierelevel - - - - - - - - - - - -
function karrierelevelCreate(bezeichnung, cb) {
  karriereleveldetail = {bezeichnung:bezeichnung }

 
  
  var karrierelevel = new Karrierelevel(karriereleveldetail);
       
  karrierelevel.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New Karrierelevel: ' + karrierelevel);
    karrierelevelarr.push(karrierelevel)
    cb(null, karrierelevel)
  }  );
}


//stellenbild - - - - - - - - - - - -
function stellenbildCreate(pfad, cb) {
    stellenbilddetail = {pfad:pfad}
  
   
    
    var stellenbild = new Stellenbild(stellenbilddetail);
         
    stellenbild.save(function (err) {
      if (err) {
        cb(err, null)
        return
      }
      console.log('New Stellenbild: ' + stellenbild);
      stellenbildarr.push(stellenbild)
      cb(null, stellenbild)
    }  );
  }

//stelle - - - - - - - - - - - -
function stelleCreate(bezeichnung, beschreibung, berufsfeld, karrierelevel, stellenbild, cb) {
  stelledetail = { 
    bezeichnung: bezeichnung,
    beschreibung: beschreibung,

  }
  if (berufsfeld != false) stelledetail.berufsfeld = berufsfeld
  if (karrierelevel != false) stelledetail.karrierelevel = karrierelevel
  if (stellenbild!= false) stelledetail.stellenbild = stellenbild
  
  var stelle = new Stelle(stelledetail);    
  stelle.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New stelle: ' + stelle);
    stellearr.push(stelle)
    cb(null, stelle)
  }  );
}


//ansprechpartner - - - - - - - - - - - -
function ansprechpartnerCreate(nachname, vorname, abteilung, profilbild, cb) {
    ansprechpartnerdetail = {nachname:nachname , vorname: vorname , abteilung: abteilung, profilbild: profilbild}
   
    
    var ansprechpartner = new Ansprechpartner(ansprechpartnerdetail);
         
    ansprechpartner.save(function (err) {
      if (err) {
        cb(err, null)
        return
      }
      console.log('New Ansprechpartner: ' + ansprechpartner);
      ansprechpartnerarr.push(ansprechpartner)
      cb(null, ansprechpartner)
    }  );
  }


//standort - - - - - - - - - - - -
function standortCreate(plz, ort, strasse, hausnummer, ansprechpartner, cb) {
  standortdetail = { 
    plz: plz,
    ort: ort,
    hausnummer: hausnummer,
    strasse: strasse
  }
  if (ansprechpartner != false) standortdetail.ansprechpartner = ansprechpartner
    
  var standort = new Standort(standortdetail);    
  standort.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New Standort: ' + standort);
    standortarr.push(standort)
    cb(null, standort)
  }  );
}










//stellenangebot - - - - - - - - - - - -
function stellenangebotCreate(beginn, stelle, unternehmensbereich, standort, ansprechpartner, cb) {
  stellenangebotdetail = { 
    beginn: beginn
  }
  if (stelle != false) stellenangebotdetail.stelle = stelle
  if (unternehmensbereich != false) stellenangebotdetail.unternehmensbereich = unternehmensbereich
  if (standort != false) stellenangebotdetail.standort = standort
  if (ansprechpartner != false) stellenangebotdetail.ansprechpartner = ansprechpartner
    
  var stellenangebot = new Stellenangebot(stellenangebotdetail);    
  stellenangebot.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New stellenangebot: ' + stellenangebot);
    stellenangebotarr.push(stellenangebot)
    cb(null, stellenangebot)
  }  );
}


function createfirst(cb) {
  async.series([
      function(callback) {
        berufsfeldCreate('Ausbildung', callback);
      },
      function(callback) {
        berufsfeldCreate('Duales Studium', callback);
      },
      function(callback) {
        berufsfeldCreate('Marketing', callback);
      },

      function(callback) {
        unternehmensbereichCreate('Fricke Holding', 'http://www.fricke.de/',
        'Die familiengeführte FRICKE Gruppe hat sich im Laufe der fast 100-jährigen Historie vom klassischen Landmaschinenhändler zu einem erfolgreichen internationalen Händler für Landmaschinen, Gartentechnik, Nutzfahrzeugen und Ersatzteilen entwickelt. Mit 2.912 Mitarbeitern - verteilt auf 64 Standorte in 25 Ländern - arbeiten wir gemeinsam am weiteren Ausbau unserer Marktposition.'
        ,  callback);
      },
      function(callback) {
        unternehmensbereichCreate('Fricke Landmaschinen', 'http://www.fricke24.de/',
        `FRICKE Landmaschinen GmbH

        Als eines der fünf größten Landtechnikhäuser in Deutschland bieten wir unseren Kunden Vielfalt, beste Erreichbarkeit und ein Höchstmaß an Service. Trotz der Größe der Unternehmensgruppe ist die Atmosphäre bei FRICKE Landmaschinen nach wie vor sehr familiär und bodenständig. Um unseren Kunden jeden Wunsch erfüllen zu können, bieten wir ein starkes Markenportfolio an Neu- und Gebrauchtmaschinen.`
        , callback);
      },
      function(callback) {
        unternehmensbereichCreate('GRANIT PARTS', 'http://www.granitparts.de/',
        `Wilhelm Fricke SE - GRANIT PARTS

        Mit dem Unternehmensbereich GRANIT bieten wir Fachhändlern in Europa Landmaschinen-, Gartentechnik-, Baumaschinen- und Nutzfahrzeug-Ersatzteile aus einer Hand. Die Ware wird aus unserem 85.000m² großen Zentrallager in Heeslingen europaweit verschickt, für das wir neue Mitarbeiter zur weiteren Unterstützung des Teams suchen.`
        , callback);
      },

      function(callback) {
        karrierelevelCreate('Berufseinsteiger', callback);
      },
      function(callback) {
        karrierelevelCreate('Schüler', callback);
      },
      function(callback) {
        karrierelevelCreate('Studenten', callback);
      },


      function(callback) {
        stellenbildCreate('https://fricke.hr4you.org/system/file/33_Titel_Mercedes_Man_Fav', callback);
      },
      function(callback) {
        stellenbildCreate('https://fricke.hr4you.org/system/file/2020-10-15_Ole_Harms_klein-2', callback);
      },
      function(callback) {
        stellenbildCreate('https://fricke.hr4you.org/system/file/service_center-6_hydraulik', callback);
      },
      ],
      // optional callback
      cb);
}




function createstelle(cb) {
  async.parallel([
      function(callback) {
        stelleCreate( 'Land- und Baumaschinenmechatroniker 2022 (m/w/d)',
        `p Deine Aufgaben
        
         p In Deiner Ausbildung zum Landmaschinenmechatroniker (m/w/d) lernst Du, wie man Maschinen aus den Bereichen Landwirtschaft, Gartenbau, Forst- und Kommunalwirtschaft repariert und wartet. Neben den Grundlagen wird Dir gezeigt, wie man mechanische, pneumatische, hydraulische und elektronische Anlagen anschließt, einstellt und prüft.
        
        
         p Was Du mitbringst:
         ul
            li Realschulabschluss oder guter Hauptschulabschluss
            li Interesse für technische Zusammenhänge, landwirtschaftliche Maschinen und praktische Tätigkeiten
            li Technisches Grundverständnis
            li Manuelles Geschick und kundenorientiertes Denken
        
        
         p Mit dem erfolgreichen Abschluss Deiner Ausbildung bietet sich Dir in der Fricke Gruppe eine Vielzahl an Einstiegsmöglichkeiten.
        
         p Nutze Deine Chance zu einer umfassenden Ausbildung in einem wachstumsstarken und zukunftsorientierten Handelsunternehmen und werde einer vonmehr als 190 Auszubildenden der Fricke Gruppe. Schicke Deine Bewerbungsunterlagen mit den letzten drei Zeugnissen per Post an Frau Janice Müller oder bewirb Dich direkt online. Wir freuen uns darauf.
        
         p Deine aussagekräftige Bewerbung richte bitte an: `,
        berufsfeldarr[0],karrierelevelarr[1],stellenbildarr[0]  ,callback)
      },
      function(callback) {
        stelleCreate('Duales Studium Betriebswirtschaftslehre 2021 (m/w/d)', 
        `p Deine Aufgaben

         p Die Ausbildung zum Betriebswirt (m/w/d) erfolgt durch ein auf sieben Semester ausgelegtes Studium an einer renommierten Fachhochschule. In der Praxisphase durchläufst Du verschiedene Abteilungen im Unternehmen. Du lernst alle kaufmännischen Aspekte und sämtliche betriebswirtschaftliche Prozesse kennen. Dabei übernimmst Du kaufmännische Tätigkeiten in nahezu allen Abteilungen.
        
         p Was Du mitbringst:
         ul
            li ein gutes Abitur oder Fachabitur
            li Interesse für betriebswirtschaftliche Zusammenhänge
            li hohes Maß an Engagement
            li Leistungsbereitschaft und Eigeninitiative
        
        
         p Mit dem erfolgreichen Abschluss Deiner Ausbildung bietet sich Dir in der Fricke Gruppe eine Vielzahl an Einstiegsmöglichkeiten.
        
         p Nutze Deine Chance zu einer umfassenden Ausbildung in einem wachstumsstarken und zukunftsorientierten Handelsunternehmen und werde einer von mehr als 190 Auszubildenden der Fricke Gruppe. Schicke Deine Bewerbungsunterlagen mit den letzten drei Zeugnissen per Post an Frau Lisa Heins oder bewirb Dich direkt online. Wir freuen uns darauf. `, 
        berufsfeldarr[1], karrierelevelarr[1],stellenbildarr[1] ,callback)
      },
      function(callback) {
        stelleCreate('(Junior) Product Manager (m/w/d) Garten & Forst', 
        `p Ihre Aufgaben:
         ul
            li Sortimentspflege und -erweiterung im Bereich Garten & Forst
            li Produktentwicklung (inkl. Produktvorschläge und Musterbegutachtungen)
            li Suche nach alternativen Lieferanten und regelmäßige Gespräche mit bestehenden und neuen Lieferanten
            li Markt- und Wettbewerbsbeobachtung
            li Technische Unterstützung und Beratung für unsere Mitarbeiter im Innen- & Außendienst
            li Durchführung von Vertriebsschulungen und Maßnahmen zur Verkaufsförderung
            li Teilnahme an Vertriebsschulungen & Events
            li Messebesuche
    
    
         ul Ihr Profil:
    
            li Abgeschlossene kaufmännische Ausbildung oder technische Ausbildung, gerne geben wir auch Berufs- oder Quereinsteigern als Junior Product Manager (m/w/d) eine Chance
            li Erste Erfahrungen im Bereich Gartentechnik, Forstwirtschaft, Bewässerung, GaLa-Bau oder aus dem Baumarktumfeld sind interessant für uns, aber keine zwingende Voraussetzung
            li Gute Kommunikationsfähigkeiten, grundlegendes technisches Verständnis und analytische Fähigkeiten
            li Interkulturelle Kompetenz
            li Reisebereitschaft
            li Englischkenntnisse in Wort und Schrift
    
    
         ul Unser Angebot an Sie:
    
            li Gutes Arbeitsklima und familiäre Atmosphäre
            li Sicherer Arbeitsplatz
            li Offene Kommunikation über alle Ebenen und kurze Entscheidungswege
            li Modern ausgestattete Arbeitsplätze und moderne Kantine
            li Fricke Academy für interne Schulungs- und Fortbildungsprogramme
            li Sorgfältige und individuelle Einarbeitung
            li Flexible Arbeitszeitmodelle
            li Urlaubs- und Weihnachtsgeld
            li Attraktive Mitarbeiterrabatte
            li Einzigartige Mitarbeiterevents
    
    
         p Nutzen Sie Ihre Chance und bewerben Sie sich direkt online oder schicken Sie uns Ihre Bewerbungsunterlagen per Post. Wir freuen uns auf Sie!
        
         p Ihre aussagekräftige Bewerbung richten Sie bitte an:`
        , berufsfeldarr[2], karrierelevelarr[0],stellenbildarr[2] ,callback)
      }
      ],
      // Optional callback
      cb);
}




function createstandort(cb) {
  async.parallel([
      function(callback) {
        standortCreate( '27404', 'Heeslingen', 'Zum Kreuzkamp','7', ansprechpartnerarr[0],callback)
      },
      function(callback) {
        standortCreate( '27404', 'Heeslingen', 'Wilhelm-Fricke-Straße','5', ansprechpartnerarr[1] ,callback)
      },
      function(callback) {
        standortCreate( '27404', 'Heeslingen', 'Zum Kreuzkamp','7', ansprechpartnerarr[2], callback)
      }
      ],
      // Optional callback
      cb);
}




function createansprechpartner(cb) {
  async.parallel([
      function(callback) {
        ansprechpartnerCreate('Stahl', 'Carsten', 'privatdetektiv','https://randomuser.me/api/portraits/men/4.jpg', callback)
      },
      function(callback) {
        ansprechpartnerCreate(' Tommy', 'Tom', 'personalrecruiting','https://randomuser.me/api/portraits/women/34.jpg', callback)
      },
      function(callback) {
        ansprechpartnerCreate('Kahrs', 'Leon', 'recruitung','https://randomuser.me/api/portraits/men/86.jpg', callback)
      }
      ],
      // Optional callback
      cb);
}



function createstellenangebot(cb) {
    async.parallel([
        function(callback) {
          stellenangebotCreate('', stellearr[0],unternehmensbereicharr[0] ,standortarr[2], ansprechpartnerarr[2],  callback)
        },
        function(callback) {
          stellenangebotCreate('', stellearr[1],unternehmensbereicharr[2] ,standortarr[1], ansprechpartnerarr[1],  callback)
        },
        function(callback) {
          stellenangebotCreate('2022-08-01',stellearr[2],unternehmensbereicharr[1] ,standortarr[0], ansprechpartnerarr[0],  callback)
        }
        ],
        // Optional callback
        cb);
}



async.series([
    createfirst,
    createansprechpartner,
    createstelle,
    createstandort,
    createstellenangebot


],
// Optional callback
function(err, results) {
    if (err) {
        console.log('FINAL ERR: '+err);
    }
    else {
        console.log('Stellenangebot: '+stellenangebotarr);
        
    }
    // All done, disconnect from database
    mongoose.connection.close();
});




