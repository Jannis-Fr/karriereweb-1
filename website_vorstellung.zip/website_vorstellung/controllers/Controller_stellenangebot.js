//Anbindung der Tabellen von der Datenbank
var Ansprechpartner = require('../models/ansprechpartner');
var Berufsfeld = require('../models/berufsfeld');

var Standort = require('../models/standort');
var Unternehmensbereich = require('../models/unternehmensbereich');
var Stellenangebot = require('../models/stellenangebot');
var Bild = require('../models/bild');
var Stellentext = require('../models/stellentext');
var Karrierelevel = require('../models/karrierelevel');



//Anbindung des express-validators
const {body,validationResult } = require('express-validator');
//async-modul wird angebunden
var async = require('async');


//funktion, welche die Stellenangebotsliste ausliest und an die Seite /stellenangebote sendet
exports.stellenangebot_list_get = function(req, res){
    //suche alle Datensätze aus der Tabelle Stellenangebote
    Stellenangebot.find({})
    //erweitere die suche mit dem dazugehörigen Ansprechpartner und dessen Standort
    .populate({
        path: 'ansprechpartner',
        populate:{path:'standort'}
        
    })
    //erweitere die suche mit der dazugehörigen Standort Tabelle
    .populate(
        'standort'
    )
    //erweitere die suche mit der dazugehörigen Stellentext Tabelle
    .populate(
        'stellentext'
    )
    //erweitere die suche mit den dazugehörigen Berufsfeldern
    .populate(
        'berufsfeld'
    )
    //erweitere die suche mit den dazugehörigen unternehmensbereichen
    .populate(
        'unternehmensbereich'
    )
    //funktion mit dem such-array von oben als übergabeparameter.
    .exec(function (err, list_stellenangebote){
        //bei einem Error wird dieser Zurückgegeben
        if(err) {return next(err);}
        //Die sucharray liste wird zur /stellenangebot seite gesendet
        res.render('stellenangebote', {stellenangebot_list: list_stellenangebote});
    });
};



//Suche nach stellen und anzahl der stellen

/*
exports.stellenangebot_list_get = function(req, res){
    async.parallel({
        stellenangebot: function(callback){
            //suche alle Datensätze aus der Tabelle Stellenangebote
            Stellenangebot.find({})
            //erweitere die suche mit dem dazugehörigen Ansprechpartner und dessen Standort
            .populate({
                path: 'ansprechpartner',
                populate:{path:'standort'}
                
            })
            //erweitere die suche mit der dazugehörigen Standort Tabelle
            .populate(
                'standort'
            )
            //erweitere die suche mit der dazugehörigen Stellentext Tabelle
            .populate(
                'stellentext'
            )
            //erweitere die suche mit den dazugehörigen Berufsfeldern
            .populate(
                'berufsfeld'
            )
            //erweitere die suche mit den dazugehörigen unternehmensbereichen
            .populate(
                'unternehmensbereich'
            )
            .exec(callback);
        },
        stellenangebot_count: function(callback){
            Stellenangebot.countDocuments({},callback);
        }
    },

        //funktion mit dem such-array von oben als übergabeparameter.
        function (err, list_stellenangebote){
            //bei einem Error wird dieser Zurückgegeben
            
            //Die sucharray liste wird zur /stellenangebot seite gesendet
            res.render('stellenangebote', {stellenangebot_list: list_stellenangebote.stellenangebot, stellenangebot_count: list_stellenangebote.stellenangebot_count});
    });
};*/




//function, welche nach einem Post im Jobsuchform das Suchergebnis
//aus der Datenbank ausliest und an /stellenangebot sendet
exports.stellenangebot_list_post = function(req, res){
    const zero_24 = "000000000000000000000000";
     
    body('level.*').escape(),
    body('freitext', 'must be empty').trim().isLength({min: 1}).escape()
    

    /*if(isset karrierelevel){
        karrierelevel={$in:["level1._id","level2._id","level3._id","level4._id"]}
    }else{
        karrierelevel="{$exists:true}"
    }
    */
    var freitext= req.body.freitext;
    var level=req.body.level;
    if(level==null){
        var karriere={$exists:true};
    }else{
       
    var karriere='{$in:["'+req.body.level+'"]}';
    
    }
Stellenangebot.find({karrierelevel:karriere},)
    .populate({
        path: 'ansprechpartner',
        populate:{path:'standort'}
        
    })
    .populate(
        'standort'
    )
    .populate(
        'stellentext'
    )
    .populate(
        'berufsfeld'
    )
    .populate(
        'unternehmensbereich'
    )
    .populate(
        'karrierelevel'
    )
    .exec(function (err, list_stellenangebote){
        if(err) {return next(err);}

        res.render('stellenangebote_post', {stellenangebot_list: list_stellenangebote, eingabe: karriere});
    });
};



//funktion, die alle benötigten information von EINEM Stellenangebot
//aus der Datenbank ausließt und an die Seite /stellenangebot/:id
//sendet
exports.stellenangebot_detail = function(req, res, next){
    
    async.parallel({
        stellenangebot: function(callback) {
            //suche das Stellenangebot mit der passenden id
            Stellenangebot.findById(req.params.id)
            //erweitere das Suchergebnis um alle benötigten Tabellen die in einer Beziehung stehen
            .populate({
                path: 'ansprechpartner',
                populate:{path:'standort'}
            })
            .populate(
                'standort'
            )
            .populate(
                'stellentext'
            )
            .populate(
                'berufsfeld'
            )
            .populate(
                'karrierelevel'
            )
            .populate(
                'unternehmensbereich'
            )
            .populate(
                'bild'
            )
             
              .exec(callback);
        },
        
        
    }, function(err, results) {
        if (err) { return next(err); }
        if (results.stellenangebot==null) { // No results.
            var err = new Error('Stelle not found');
            err.status = 404;
            return next(err);
        }
        // Successful, so render.
            

        res.render('stellenangebot', { title: results.stellenangebot.bezeichnung,stellenangebot: results.stellenangebot});

    });

};
