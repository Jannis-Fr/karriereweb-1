/*************************************************/

/* funktionen für das ausfahren der navigationsleiste
    am rechten Rand*/

/**************************************************/
//Funktion, welche das Ausfahren regelt
function openNav() {
  //Das Rote Sidepanel wird von recht Ausgefahren
  document.getElementById("mySidepanel").style.width = "480px";
  //Die verdunkelte fläche im hintergrund wird ausgefahren
  document.getElementById("mySidepanel_left").style.width = "100vw";
  //Das Scrollen wird deaktiviert
  document.getElementById("myBody").style.overflowY = "hidden";
    }
//Funktion, welche das Einfahren regelt
function closeNav() {
  //Das Rote Sidepanel auf der Rechten Seite wird eingefahren  
  document.getElementById("mySidepanel").style.width = "0";
  //Der verdunkelte hintergrund verschwindet
  document.getElementById("mySidepanel_left").style.width = "0";
  //Das Scrollen wird aktiviert
  document.getElementById("myBody").style.overflowY = "scroll";

    }
    

  

    /*************************************************/

    /* funktion für das Ausfahren der oberen Leiste beim
        Runterscrollen*/

    /**************************************************/
    //Wenn gescrollt wird, wird die Funktion ausgeführt
    window.onscroll = function() {scrollFunction()};


    function scrollFunction() {
      //Wenn weiter als 650px gescrollt wurde
      if (document.body.scrollTop > 650 || document.documentElement.scrollTop > 650) {
        //wird die Topbar ausgefahren
        document.getElementById("navbar").style.top = "0";
      } else {
        //Sonst bleibt die Topbar versteckt
        document.getElementById("navbar").style.top = "-150px";
      }
    } 

    /*************************************************/

    /* 4 funktionen, welche die checkboxen im jobsuch-
        formular ausfahren*/

    /**************************************************/
    //ausgefahren ist falsch ist standart
    var expanded = false;
    //function zum ausfahren der Checkboxen im Jobsuchform
    function showCheckbox_1() {
    //Checkbox 1 wird mit der ID deklariert
    var checkbox_1 = document.getElementById("checkbox_1");
    //Wenn die Checkbox ausgefahren wird
    if (!expanded) {
    //wird die ausgefahrene Checkbox angezeigt
    checkbox_1.style.display = "block";
    //ausgefahren ist wahr
    expanded = true;
    } else {
    //ansonsten ist die Ausgefahrene checkbox versteckt
    checkbox_1.style.display = "none";
    //ausgefahren=falsch
    expanded = false;
    }
    }
    
    var expanded = false;
    function showCheckbox_2() {
    var checkboxes = document.getElementById("checkbox_2");
    if (!expanded) {
    checkboxes.style.display = "block";
    expanded = true;
    } else {
    checkboxes.style.display = "none";
    expanded = false;
    }
    }
    var expanded = false;
    function showCheckbox_3() {
    var checkboxes = document.getElementById("checkbox_3");
    if (!expanded) {
    checkboxes.style.display = "block";
    expanded = true;
    } else {
    checkboxes.style.display = "none";
    expanded = false;
    }
    }
    var expanded = false;
    function showCheckbox_4() {
    var checkboxes = document.getElementById("checkbox_4");
    if (!expanded) {
    checkboxes.style.display = "block";
    expanded = true;
    } else {
    checkboxes.style.display = "none";
    expanded = false;
    }
    }
    
    /*************************************************/

    /* funktion für die Tabs im article (z.B. /Das sind wir)*/

    /**************************************************/
    //wenn auf eines der Tabs in der Tab-bar geklickt wird
    function openCity(evt, cityName) {
      //zähler i , tabcontent für den inhalt der Tabs, tablinks für die Tabnavigationsbar
      var i, tabcontent, tablinks;
      //tabcontent wird die aktuelle Id des offenen Tabs zugewiesen
      tabcontent = document.getElementsByClassName("tabcontent");
      //Der Content wird passend weit ausgefahren
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    }
    


    /*************************************************/

    /* funktion für das zählen der stellenangebote*/

    /**************************************************/

 