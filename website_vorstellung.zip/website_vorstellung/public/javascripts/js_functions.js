/*************************************************/

/* funktionen für das ausfahren der navigationsleiste
    am rechten Rand*/

/**************************************************/

function openNav() {
    document.getElementById("mySidepanel").style.width = "480px";
    }
    function closeNav() {
    document.getElementById("mySidepanel").style.width = "0";
    }

  

    /*************************************************/

    /* funktion für das Ausfahren der oberen Leiste beim
        Runterscrollen*/

    /**************************************************/

    window.onscroll = function() {scrollFunction()};


    function scrollFunction() {
      if (document.body.scrollTop > 650 || document.documentElement.scrollTop > 650) {
        document.getElementById("navbar").style.top = "0";
      } else {
        document.getElementById("navbar").style.top = "-150px";
      }
    } 

    /*************************************************/

    /* 4 funktionen, welche die checkboxen im jobsuch-
        formular ausfahren*/

    /**************************************************/
    var expanded = false;
    function showCheckbox_1() {
    var checkbox_1 = document.getElementById("checkbox_1");
    if (!expanded) {
    checkbox_1.style.display = "block";
    expanded = true;
    } else {
    checkbox_1.style.display = "none";
    expanded = false;
    }
    }
    
    var expanded = false;
    function showCheckbox_2() {
    var checkboxes = document.getElementById("checkbox_2");
    if (!expanded) {
    checkboxes.style.display = "block";
    expanded = true;
    } else {
    checkboxes.style.display = "none";
    expanded = false;
    }
    }
    var expanded = false;
    function showCheckbox_3() {
    var checkboxes = document.getElementById("checkbox_3");
    if (!expanded) {
    checkboxes.style.display = "block";
    expanded = true;
    } else {
    checkboxes.style.display = "none";
    expanded = false;
    }
    }
    var expanded = false;
    function showCheckbox_4() {
    var checkboxes = document.getElementById("checkbox_4");
    if (!expanded) {
    checkboxes.style.display = "block";
    expanded = true;
    } else {
    checkboxes.style.display = "none";
    expanded = false;
    }
    }
    
    /*************************************************/

    /* funktion für die Tabs im article (z.B. /Das sind wir)*/

    /**************************************************/

    function openCity(evt, cityName) {
      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    }
    

    
