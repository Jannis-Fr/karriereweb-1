function openNav() {
    document.getElementById("mySidepanel").style.width = "480px";
    }
    function closeNav() {
    document.getElementById("mySidepanel").style.width = "0";
    }