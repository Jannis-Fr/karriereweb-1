var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var das_sind_wirRouter = require('./routes/das_sind_wir');
var erfahrungsberichteRouter = require('./routes/erfahrungsberichte');
var mitarbeiterentwicklungRouter = require('./routes/mitarbeiterentwicklung');
var fricke_foerdertRouter = require('./routes/fricke_foerdert');
var fricke_sozial_day_abstimmungRouter = require('./routes/fricke_sozial_day_abstimmung');
var schuelerRouter = require('./routes/schueler');
var fricke_azubi_infotagRouter = require('./routes/fricke_azubi_infotag');
var ausbildungRouter = require('./routes/ausbildung');
var praktikumRouter = require('./routes/praktikum');
var duales_studiumRouter = require('./routes/duales_studium');
var schuelerjobsRouter = require('./routes/schuelerjobs');
var bewerbungstipps_fuer_azubis = require('./routes/bewerbungstipps_fuer_azubis');
var blogRouter= require('./routes/blog');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/das-sind-wir', das_sind_wirRouter);
app.use('/erfahrungsberichte',erfahrungsberichteRouter);
app.use('/mitarbeiterentwicklung',mitarbeiterentwicklungRouter);
app.use('/das-sind-wir/fricke-foerdert',fricke_foerdertRouter);
app.use('/fricke-sozial-day-abstimmung',fricke_sozial_day_abstimmungRouter);
app.use('/schueler', schuelerRouter);
app.use('/schueler/fricke-azubi-infotag', fricke_azubi_infotagRouter);
app.use('/schueler/ausbildung',ausbildungRouter);
app.use('/schueler/praktikum',praktikumRouter);
app.use('/schueler/duales-studium',duales_studiumRouter);
app.use('/schueler/schuelerjobs',schuelerjobsRouter);
app.use('/schueler/bewerbungstipps-fuer-azubis',bewerbungstipps_fuer_azubis);
app.use('/karriere/blog', blogRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
