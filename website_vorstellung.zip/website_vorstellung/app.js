var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var das_sind_wirRouter = require('./routes/das_sind_wir');
var erfahrungsberichteRouter = require('./routes/erfahrungsberichte');
var mitarbeiterentwicklungRouter = require('./routes/mitarbeiterentwicklung');
var fricke_foerdertRouter = require('./routes/fricke_foerdert');
var fricke_social_day_abstimmungRouter = require('./routes/fricke_social_day_abstimmung');

var schuelerRouter = require('./routes/schueler');
var fricke_azubi_infotagRouter = require('./routes/fricke_azubi_infotag');

var ausbildungRouter = require('./routes/ausbildung');
var gewerbliche_technische_ausbildungRouter = require('./routes/gewerbliche_technische_ausbildung');
var mechatronikerRouter = require('./routes/mechatroniker');
var landmaschinenmechatronikerRouter = require('./routes/landmaschinenmechatroniker');
var kfz_mechatronikerRouter = require('./routes/kfz_mechatroniker');
var metallbauerRouter = require('./routes/metallbauer');

var kaufmaennische_ausbildungRouter = require('./routes/kaufmaennische_ausbildung');
var ecommerceRouter = require('./routes/ecommerce');
var gross_und_aussenhandelRouter = require('./routes/gross_und_aussenhandel');
var lagerlogistikRouter =require('./routes/lagerlogistik');
var industriekaufmannRouter = require('./routes/industriekaufmann');
var fachinformatikerRouter = require('./routes/fachinformatiker');
var informatikkaufmannRouter = require('./routes/informatikkaufmann');

var schuelerpraktikumRouter = require('./routes/schuelerpraktikum');
var duales_studiumRouter = require('./routes/duales_studium');

var agrarmanagementRouter = require('./routes/agrarmanagement');
var betriebswirtschaftslehreRouter = require('./routes/betriebswirtschaftslehre');
var wirtschaftsinformatikRouter = require('./routes/wirtschaftsinformatik');
var wirtschaftsingenieurwesenRouter = require('./routes/wirtschaftsingenieurwesen')

var schuelerjobsRouter = require('./routes/schuelerjobs');
var bewerbungstipps_fuer_azubis = require('./routes/bewerbungstipps_fuer_azubis');
var bewerbungsprozess_bewerbungstippsRouter = require('./routes/bewerbungsprozess_bewerbungstipps');

var studentenRouter = require('./routes/studenten');
var abschlussarbeitRouter = require('./routes/abschlussarbeit');
var studentenpraktikumRouter = require('./routes/studentenpraktikum');

var berufseinsteigerRouter = require('./routes/berufseinsteiger');
var berufseinstiegRouter = require('./routes/berufseinstieg');
var traineeprogrammeRouter = require('./routes/traineeprogramme');

var berufserfahreneRouter = require('./routes/berufserfahrene');
var einkaufRouter = require('./routes/einkauf');
var finanzencontrollingRouter = require('./routes/finanzencontrolling');
var itRouter = require('./routes/it');
var logistikRouter = require('./routes/logistik');
var marketingRouter = require('./routes/marketing');
var produktionRouter = require('./routes/produktion');
var vertriebRouter = require('./routes/vertrieb');
var werkstattRouter = require('./routes/werkstatt');

var stellenangebotRouter = require('./routes/stellenangebote');
var faqRouter = require('./routes/faq');
var blogRouter= require('./routes/blog');
var kontaktRouter= require('./routes/kontakt');
var datenschutzRouter= require('./routes/datenschutz');
var testRouter =require('./routes/test');
var app = express();




//Set up mongoose connection
var mongoose = require('mongoose');
var mongoDB = 'mongodb://127.0.0.1:27017/dbstelletest2';
mongoose.connect(mongoDB, { useNewUrlParser: true , useUnifiedTopology: true});
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

var Stellenangebot=require('./models/stellenangebot');
//Anzahl der Stellenangebote Zählen
  Stellenangebot.countDocuments({}, function(err, c) {
    //!!!!! Globale Variable !!!!!!
      stellenangebot_count=c;
  });
 


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

app.use('/das-sind-wir', das_sind_wirRouter);
app.use('/erfahrungsberichte',erfahrungsberichteRouter);
app.use('/mitarbeiterentwicklung',mitarbeiterentwicklungRouter);
app.use('/das-sind-wir/fricke-foerdert',fricke_foerdertRouter);
app.use('/fricke-social-day-abstimmung',fricke_social_day_abstimmungRouter);

app.use('/schueler', schuelerRouter);
app.use('/schueler/fricke-azubi-infotag', fricke_azubi_infotagRouter);

app.use('/schueler/ausbildung',ausbildungRouter);
app.use('/schueler/ausbildung/gewerbliche-technische-ausbildung',gewerbliche_technische_ausbildungRouter);
app.use('/schueler/ausbildung/gewerbliche-technische-ausbildung/mechatroniker-anlagentechnik',mechatronikerRouter);
app.use('/schueler/ausbildung/gewerbliche-technische-ausbildung/landmaschinenmechatroniker',landmaschinenmechatronikerRouter);
app.use('/schueler/ausbildung/gewerbliche-technische-ausbildung/kfz-mechatroniker',kfz_mechatronikerRouter);
app.use('/schueler/ausbildung/gewerbliche-technische-ausbildung/metallbauer',metallbauerRouter);

app.use('/schueler/ausbildung/kaufmaennische-ausbildung',kaufmaennische_ausbildungRouter);
app.use('/schueler/ausbildung/kaufmaennische-ausbildung/kauffrau-kaufmann-im-e-commerce',ecommerceRouter);
app.use('/schueler/ausbildung/kaufmaennische-ausbildung/kaufmann-im-gross-und-aussenhandel',gross_und_aussenhandelRouter);
app.use('/schueler/ausbildung/kaufmaennische-ausbildung/fachkraft-fuer-lagerlogistik',lagerlogistikRouter);
app.use('/schueler/ausbildung/kaufmaennische-ausbildung/industriekaufmann',industriekaufmannRouter);
app.use('/schueler/ausbildung/kaufmaennische-ausbildung/fachinformatiker',fachinformatikerRouter);
app.use('/schueler/ausbildung/kaufmaennische-ausbildung/informatikkaufmann',informatikkaufmannRouter);


app.use('/schueler/praktikum',schuelerpraktikumRouter);
app.use('/schueler/duales-studium',duales_studiumRouter);

app.use('/schueler/duales-studium/agrarmanagement',agrarmanagementRouter);
app.use('/schueler/duales-studium/betriebswirtschaftslehre',betriebswirtschaftslehreRouter);
app.use('/schueler/duales-studium/wirtschaftsinformatik',wirtschaftsinformatikRouter);
app.use('/schueler/duales-studium/wirtschaftsingenieurwesen',wirtschaftsingenieurwesenRouter);

app.use('/schueler/schuelerjobs',schuelerjobsRouter);
app.use('/schueler/bewerbungstipps-fuer-azubis',bewerbungstipps_fuer_azubis);
app.use('/schueler/bewerbungsprozess-bewerbungstipps',bewerbungsprozess_bewerbungstippsRouter);

app.use('/studenten',studentenRouter);
app.use('/studenten/abschlussarbeit',abschlussarbeitRouter);
app.use('/studenten/praktikum',studentenpraktikumRouter);

app.use('/berufseinsteiger',berufseinsteigerRouter);
app.use('/berufseinsteiger/berufseinstieg',berufseinstiegRouter);
app.use('/berufseinsteiger/traineeprogramme',traineeprogrammeRouter);

app.use('/berufserfahrene',berufserfahreneRouter);
app.use('/berufserfahrene/einkauf',einkaufRouter);
app.use('/berufserfahrene/finanzencontrolling',finanzencontrollingRouter);
app.use('/berufserfahrene/it',itRouter);
app.use('/berufserfahrene/logistik',logistikRouter);
app.use('/berufserfahrene/marketing',marketingRouter);
app.use('/berufserfahrene/produktion',produktionRouter);
app.use('/berufserfahrene/vertrieb',vertriebRouter);
app.use('/berufserfahrene/werkstatt',werkstattRouter);

app.use('/stellenangebote',stellenangebotRouter);
app.use('/faq',faqRouter);
app.use('/karriere/blog', blogRouter);
app.use('/kontakt', kontaktRouter);
app.use('/datenschutz', datenschutzRouter);
app.use('/test',testRouter);


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
