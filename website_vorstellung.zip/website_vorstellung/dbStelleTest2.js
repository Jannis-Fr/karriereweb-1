#! /usr/bin/env node

console.log('This script populates some test objekts to your database. Specified database as argument - e.g.: karrieredb mongodb+srv://cooluser:coolpassword@cluster0.a9azn.mongodb.net/local_library?retryWrites=true');

// Get arguments passed on command line
var userArgs = process.argv.slice(2);
/*
if (!userArgs[0].startsWith('mongodb')) {
    console.log('ERROR: You need to specify a valid mongodb URL as the first argument');
    return
}
*/
var async = require('async')
var Ansprechpartner = require('./models/ansprechpartner')
var Berufsfeld = require('./models/berufsfeld')
var Karrierelevel = require('./models/karrierelevel')
var Stellentext = require('./models/stellentext')
var Bild = require('./models/bild')
var Standort = require('./models/standort')
var Stellenangebot = require('./models/stellenangebot')

var Unternehmensbereich = require('./models/unternehmensbereich')


var mongoose = require('mongoose');
var mongoDB = userArgs[0];
mongoose.connect(mongoDB, {useNewUrlParser: true, useUnifiedTopology: true});
mongoose.Promise = global.Promise;
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

var ansprechpartnerarr = []
var berufsfeldarr = []
var karrierelevelarr = []
var stellentextarr = []
var bildarr = []
var standortarr = []
var stellenangebotarr = []

var unternehmensbereicharr = []


//unternehmensbereich - - - - - - - - - - - -
function unternehmensbereichCreate(bezeichnung, homepage, beschreibung, logo,cb) {
  unternehmensbereichdetail = {bezeichnung:bezeichnung , logo}
  if (homepage != false) unternehmensbereichdetail.homepage = homepage
  if (beschreibung != false) unternehmensbereichdetail.beschreibung = beschreibung
  
  var unternehmensbereich = new Unternehmensbereich(unternehmensbereichdetail);
       
  unternehmensbereich.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New Unternehmensbereich: ' + unternehmensbereich);
    unternehmensbereicharr.push(unternehmensbereich)
    cb(null, unternehmensbereich)
  }  );
}



//berufsfeld - - - - - - - - - - - -
function berufsfeldCreate(bezeichnung, cb) {
  berufsfelddetail = {bezeichnung:bezeichnung } 
  
  var berufsfeld = new Berufsfeld(berufsfelddetail);
       
  berufsfeld.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New Berufsfeld: ' + berufsfeld);
    berufsfeldarr.push(berufsfeld)
    cb(null, berufsfeld)
  }  );
}


//karrierelevel - - - - - - - - - - - -
function karrierelevelCreate(bezeichnung, cb) {
  karriereleveldetail = {bezeichnung:bezeichnung }

 
  
  var karrierelevel = new Karrierelevel(karriereleveldetail);
       
  karrierelevel.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New Karrierelevel: ' + karrierelevel);
    karrierelevelarr.push(karrierelevel)
    cb(null, karrierelevel)
  }  );
}

//stellentext- - - - - - - - - - - -
function stellentextCreate(bezeichnung, pfad, cb) {
  stellentextdetail = {bezeichnung:bezeichnung, pfad:pfad}

 
  
  var stellentext = new Stellentext(stellentextdetail);
       
  stellentext.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New Stellentext: ' + stellentext);
    stellentextarr.push(stellentext)
    cb(null, stellentext)
  }  );
}



//bild - - - - - - - - - - - -
function bildCreate(pfad, cb) {
    bilddetail = {pfad:pfad}
  
   
    
    var bild = new Bild(bilddetail);
         
    bild.save(function (err) {
      if (err) {
        cb(err, null)
        return
      }
      console.log('New Bild: ' + bild);
      bildarr.push(bild)
      cb(null, bild)
    }  );
  }



//ansprechpartner - - - - - - - - - - - -
function ansprechpartnerCreate(nachname, vorname, standort,abteilung, profilbild, cb) {
    ansprechpartnerdetail = {nachname:nachname , vorname: vorname , abteilung: abteilung, profilbild: profilbild}
    if (standort != false) ansprechpartnerdetail.standort = standort
    
    var ansprechpartner = new Ansprechpartner(ansprechpartnerdetail);
         
    ansprechpartner.save(function (err) {
      if (err) {
        cb(err, null)
        return
      }
      console.log('New Ansprechpartner: ' + ansprechpartner);
      ansprechpartnerarr.push(ansprechpartner)
      cb(null, ansprechpartner)
    }  );
  }


//standort - - - - - - - - - - - -
function standortCreate(plz, ort, strasse, hausnummer,  cb) {
  standortdetail = { 
    plz: plz,
    ort: ort,
    hausnummer: hausnummer,
    strasse: strasse
  }
  
    
  var standort = new Standort(standortdetail);    
  standort.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New Standort: ' + standort);
    standortarr.push(standort)
    cb(null, standort)
  }  );
}










//stellenangebot - - - - - - - - - - - -
function stellenangebotCreate(stellentext, beginn, berufsfeld, karrierelevel, bild, unternehmensbereich, standort, ansprechpartner, cb) {
  stellenangebotdetail = { 
   beginn: beginn
  }
  if (stellentext != false) stellenangebotdetail.stellentext = stellentext
  if (berufsfeld != false) stellenangebotdetail.berufsfeld = berufsfeld
  if (karrierelevel != false) stellenangebotdetail.karrierelevel = karrierelevel
  if (bild != false) stellenangebotdetail.bild = bild
  if (unternehmensbereich != false) stellenangebotdetail.unternehmensbereich = unternehmensbereich
  if (standort != false) stellenangebotdetail.standort = standort
  if (ansprechpartner != false) stellenangebotdetail.ansprechpartner = ansprechpartner
    
  var stellenangebot = new Stellenangebot(stellenangebotdetail);    
  stellenangebot.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New stellenangebot: ' + stellenangebot);
    stellenangebotarr.push(stellenangebot)
    cb(null, stellenangebot)
  }  );
}


function createfirst(cb) {
  async.series([
      function(callback) {
        berufsfeldCreate('Ausbildung', callback);
      },
      function(callback) {
        berufsfeldCreate('Duales Studium', callback);
      },
      function(callback) {
        berufsfeldCreate('Marketing', callback);
      },

      function(callback) {
        unternehmensbereichCreate('Fricke Holding', 'http://www.fricke.de/',
        's'
        , 'https://fricke.hr4you.org/system/file/Fricke_rgb_color_neu', callback);
      },
      function(callback) {
        unternehmensbereichCreate('Fricke Landmaschinen', 'http://www.fricke24.de/',
        `FRICKE Landmaschinen GmbH

        Als eines der fünf größten Landtechnikhäuser in Deutschland bieten wir unseren Kunden Vielfalt, beste Erreichbarkeit und ein Höchstmaß an Service. Trotz der Größe der Unternehmensgruppe ist die Atmosphäre bei FRICKE Landmaschinen nach wie vor sehr familiär und bodenständig. Um unseren Kunden jeden Wunsch erfüllen zu können, bieten wir ein starkes Markenportfolio an Neu- und Gebrauchtmaschinen.`
        ,'https://fricke.hr4you.org/system/file/Fricke_Landmaschinen_rgb_color_neu', callback);
      },
      function(callback) {
        unternehmensbereichCreate('GRANIT PARTS', 'http://www.granitparts.de/',
        `Wilhelm Fricke SE - GRANIT PARTS

        Mit dem Unternehmensbereich GRANIT bieten wir Fachhändlern in Europa Landmaschinen-, Gartentechnik-, Baumaschinen- und Nutzfahrzeug-Ersatzteile aus einer Hand. Die Ware wird aus unserem 85.000m² großen Zentrallager in Heeslingen europaweit verschickt, für das wir neue Mitarbeiter zur weiteren Unterstützung des Teams suchen.`
        , 'https://fricke.hr4you.org/system/file/wilhelmfricke_granit-300dpi_18318_3093',callback);
      },

      function(callback) {
        karrierelevelCreate('Berufseinsteiger', callback);
      },
      function(callback) {
        karrierelevelCreate('Schüler', callback);
      },
      function(callback) {
        karrierelevelCreate('Studenten', callback);
      },

      function(callback) {
        stellentextCreate('Land- und Baumaschinenmechatroniker 2022 (m/w/d)', `<p class="fett">Deine Aufgaben</p>
        <p>In Deiner Ausbildung zum Landmaschinenmechatroniker (m/w/d) lernst Du, wie man Maschinen aus den Bereichen Landwirtschaft, Gartenbau, Forst- und Kommunalwirtschaft repariert und wartet. Neben den Grundlagen wird Dir gezeigt, wie man mechanische, pneumatische, hydraulische und elektronische Anlagen anschließt, einstellt und prüft.</p>
            
        <p class="fett">Was Du mitbringst:</p>
            <ul>
                <li>Realschulabschluss oder guter Hauptschulabschluss</li>
                <li>Interesse für technische Zusammenhänge, landwirtschaftliche Maschinen und praktische Tätigkeiten</li>
                <li>Technisches Grundverständnis</li>
                <li>Manuelles Geschick und kundenorientiertes Denken</li>
            </ul>    
                
        <p>Mit dem erfolgreichen Abschluss Deiner Ausbildung bietet sich Dir in der Fricke Gruppe eine Vielzahl an Einstiegsmöglichkeiten.</p>
                
        <p>Nutze Deine Chance zu einer umfassenden Ausbildung in einem wachstumsstarken und zukunftsorientierten Handelsunternehmen und werde einer vonmehr als 190 Auszubildenden der Fricke Gruppe. Schicke Deine Bewerbungsunterlagen mit den letzten drei Zeugnissen per Post an Frau Janice Müller oder bewirb Dich direkt online. Wir freuen uns darauf.</p>
                
        <p>Deine aussagekräftige Bewerbung richte bitte an:</p>`, callback);
      },
      function(callback) {
        stellentextCreate('Duales Studium Betriebswirtschaftslehre 2021 (m/w/d)', `<p>Deine Aufgaben</p>
        <p>Die Ausbildung zum Betriebswirt (m/w/d) erfolgt durch ein auf sieben Semester ausgelegtes Studium an einer renommierten Fachhochschule. In der Praxisphase durchläufst Du verschiedene Abteilungen im Unternehmen. Du lernst alle kaufmännischen Aspekte und sämtliche betriebswirtschaftliche Prozesse kennen. Dabei übernimmst Du kaufmännische Tätigkeiten in nahezu allen Abteilungen.</p>
            
        <p>Was Du mitbringst:</p>
            <ul>
                <li>ein gutes Abitur oder Fachabitur</li>
                <li>Interesse für betriebswirtschaftliche Zusammenhänge</li>
                <li>hohes Maß an Engagement</li>
                <li>Leistungsbereitschaft und Eigeninitiative</li>
            </ul>    
                
        <p>Mit dem erfolgreichen Abschluss Deiner Ausbildung bietet sich Dir in der Fricke Gruppe eine Vielzahl an Einstiegsmöglichkeiten.</p>
                
        <p>Nutze Deine Chance zu einer umfassenden Ausbildung in einem wachstumsstarken und zukunftsorientierten Handelsunternehmen und werde einer vonmehr als 190 Auszubildenden der Fricke Gruppe. Schicke Deine Bewerbungsunterlagen mit den letzten drei Zeugnissen per Post an Frau Janice Müller oder bewirb Dich direkt online. Wir freuen uns darauf.</p>
                
        <p>Deine aussagekräftige Bewerbung richte bitte an:</p>`, callback);
      },
      function(callback) {
        stellentextCreate('(Junior) Product Manager (m/w/d) Garten & Forst', `<p class="fett">Ihre Aufgaben:</p>
        <ul>
            <li>Sortimentspflege und -erweiterung im Bereich Garten & Forst</li>
            <li>Produktentwicklung (inkl. Produktvorschläge und Musterbegutachtungen)</li>
            <li>Suche nach alternativen Lieferanten und regelmäßige Gespräche mit bestehenden und neuen Lieferanten</li>
            <li>Markt- und Wettbewerbsbeobachtung</li>
            <li>Technische Unterstützung und Beratung für unsere Mitarbeiter im Innen- & Außendienst</li>
            <li>Durchführung von Vertriebsschulungen und Maßnahmen zur Verkaufsförderung</li>
            <li>Teilnahme an Vertriebsschulungen & Events</li>
            <li>Messebesuche</li>
        </ul>
        <p class="fett">Ihr Profil:</p>
        <ul>
            <li>Abgeschlossene kaufmännische Ausbildung oder technische Ausbildung, gerne geben wir auch Berufs- oder Quereinsteigern als Junior Product Manager (m/w/d) eine Chance</li>
            <li>Erste Erfahrungen im Bereich Gartentechnik, Forstwirtschaft, Bewässerung, GaLa-Bau oder aus dem Baumarktumfeld sind interessant für uns, aber keine zwingende Voraussetzung</li>
            <li>Gute Kommunikationsfähigkeiten, grundlegendes technisches Verständnis und analytische Fähigkeiten</li>
            <li>Interkulturelle Kompetenz</li>
            <li>Reisebereitschaft</li>
            <li>Englischkenntnisse in Wort und Schrift</li>
        </ul>
        <p class="fett">Unser Angebot an Sie:</p>
        <ul>
            <li>Gutes Arbeitsklima und familiäre Atmosphäre</li>
            <li>Sicherer Arbeitsplatz</li>
            <li>Offene Kommunikation über alle Ebenen und kurze Entscheidungswege</li>
            <li>Modern ausgestattete Arbeitsplätze und moderne Kantine</li>
            <li>Fricke Academy für interne Schulungs- und Fortbildungsprogramme</li>
            <li>Sorgfältige und individuelle Einarbeitung</li>
            <li>Flexible Arbeitszeitmodelle</li>
            <li>Urlaubs- und Weihnachtsgeld</li>
            <li>Attraktive Mitarbeiterrabatte</li>
            <li>Einzigartige Mitarbeiterevents</li>
        </ul>
        <p>Nutzen Sie Ihre Chance und bewerben Sie sich direkt online oder schicken Sie uns Ihre Bewerbungsunterlagen per Post. Wir freuen uns auf Sie!</p>
        <p>Ihre aussagekräftige Bewerbung richten Sie bitte an:</p>`, callback);
      },


      function(callback) {
        bildCreate('https://fricke.hr4you.org/system/file/33_Titel_Mercedes_Man_Fav', callback);
      },
      function(callback) {
        bildCreate('https://fricke.hr4you.org/system/file/2020-10-15_Ole_Harms_klein-2', callback);
      },
      function(callback) {
        bildCreate('https://fricke.hr4you.org/system/file/service_center-6_hydraulik', callback);
      },
      ],
      // optional callback
      cb);
}









function createstandort(cb) {
  async.parallel([
      function(callback) {
        standortCreate( '27404', 'Heeslingen', 'Zum Kreuzkamp','7', callback)
      },
      function(callback) {
        standortCreate( '27404', 'Heeslingen', 'Wilhelm-Fricke-Straße','5', callback)
      },
      function(callback) {
        standortCreate( '27404', 'Heeslingen', 'Zum Kreuzkamp','7',  callback)
      }
      ],
      // Optional callback
      cb);
}




function createansprechpartner(cb) {
  async.parallel([
      function(callback) {
        ansprechpartnerCreate('Stahl', 'Carsten', standortarr[0], 'privatdetektiv','https://randomuser.me/api/portraits/men/4.jpg', callback)
      },
      function(callback) {
        ansprechpartnerCreate(' Tommy', 'Tom', standortarr[1], 'personalrecruiting','https://randomuser.me/api/portraits/women/34.jpg', callback)
      },
      function(callback) {
        ansprechpartnerCreate('Kahrs', 'Leon', standortarr[2], 'recruitung','https://randomuser.me/api/portraits/men/86.jpg', callback)
      }
      ],
      // Optional callback
      cb);
}



function createstellenangebot(cb) {
    async.parallel([
        function(callback) {
          stellenangebotCreate(stellentextarr[0], '2022-08-01',berufsfeldarr[0],karrierelevelarr[1],bildarr[0],unternehmensbereicharr[0] ,standortarr[2], ansprechpartnerarr[2],  callback)
        },
        function(callback) {
          stellenangebotCreate(stellentextarr[1], '2022-08-01', berufsfeldarr[1], karrierelevelarr[1],bildarr[1],unternehmensbereicharr[2] ,standortarr[1], ansprechpartnerarr[1],  callback)
        },
        function(callback) {
          stellenangebotCreate(stellentextarr[2], '',berufsfeldarr[2], karrierelevelarr[0],bildarr[2],unternehmensbereicharr[1] ,standortarr[0], ansprechpartnerarr[0],  callback)
        }
        ],
        // Optional callback
        cb);
}



async.series([
    createfirst,
    createstandort,
    createansprechpartner,
    createstellenangebot


],
// Optional callback
function(err, results) {
    if (err) {
        console.log('FINAL ERR: '+err);
    }
    else {
        console.log('Stellenangebot: '+stellenangebotarr);
        
    }
    // All done, disconnect from database
    mongoose.connection.close();
});




