var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var UnternehmensbereichSchema = new Schema(
  {
    bezeichnung: {type: String, required: true, minLength: 3, maxLength: 100},
    homepage: {type: String, minLength: 3, maxLength: 100},
    beschreibung: {type: String, required: true},
    logo: {type: String, required:true},

}
);

// Virtual for Unternehmensbereich's URL
UnternehmensbereichSchema
.virtual('url')
.get(function () {
  return '/catalog/unternehmensbereich/' + this._id;
});

//Export model
module.exports = mongoose.model('Unternehmensbereich', UnternehmensbereichSchema);