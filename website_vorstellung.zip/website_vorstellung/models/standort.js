var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var StandortSchema = new Schema(
  {
    plz: {type: String, required: true, minLength: 3, maxLength: 10},
    ort: {type: String, required: true, minLength: 3, maxLength: 100},
    strasse: {type: String, required: true},
    hausnummer: {type: String},
    

}
);

// Virtual for Standort's URL
StandortSchema
.virtual('url')
.get(function () {
  return '/catalog/standort/' + this._id;
});

//Export model
module.exports = mongoose.model('Standort', StandortSchema);