var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var AnsprechpartnerSchema = new Schema(
  {
    nachname: {type: String, required: true, minLength: 3, maxLength: 100},
    vorname: {type: String, required: true, minLength: 3, maxLength: 100},
    standort: {type: Schema.Types.ObjectId, ref: 'Standort'},
    abteilung: {type: String, required: true, minLength: 3, maxLength: 100},
    profilbild: {type: String, required: true, minLength: 3, maxLength: 100}
    
  }
);

// Virtual for Ansprechpartner's URL
AnsprechpartnerSchema
.virtual('url')
.get(function () {
  return '/catalog/ansprechpartner/' + this._id;
});

//Export model
module.exports = mongoose.model('Ansprechpartner', AnsprechpartnerSchema);