var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var BildSchema = new Schema(
    {
        pfad: {type: String, required: true},
    }
);

// Virtual for Stellenbilds URL
BildSchema
.virtual('url')
.get(function () {
    return '/stellenangebot/bild/' + this._id;
});

//Export model
module.exports = mongoose.model('Bild', BildSchema);