var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var BerufsfeldSchema = new Schema(
    {
        bezeichnung: {type: String, required: true},
    }
);

// Virtual for Berufsfeld's URL
BerufsfeldSchema
.virtual('url')
.get(function () {
    return '/stellenangebot/berufsfeld/' + this._id;
});

//Export model
module.exports = mongoose.model('Berufsfeld', BerufsfeldSchema);