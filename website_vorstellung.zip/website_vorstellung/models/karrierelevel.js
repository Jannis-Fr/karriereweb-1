var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var KarrierelevelSchema = new Schema(
    {
        bezeichnung: {type: String, required: true},
    }
);

// Virtual for Karrierelevel's URL
KarrierelevelSchema
.virtual('url')
.get(function () {
    return '/stellenangebot/karrierelevel/' + this._id;
});

//Export model
module.exports = mongoose.model('Karrierelevel', KarrierelevelSchema);