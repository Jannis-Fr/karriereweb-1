var mongoose = require('mongoose');
const { DateTime } = require("luxon");

var Schema = mongoose.Schema;

var StellenangebotSchema = new Schema(
  {
    stellentext: {type: Schema.Types.ObjectId, ref: 'Stellentext'},
    beginn: {type: Date},

    berufsfeld: [{type: Schema.Types.ObjectId, ref: 'Berufsfeld'}],
    karrierelevel: [{type: Schema.Types.ObjectId, ref: 'Karrierelevel'}],
    bild: {type: Schema.Types.ObjectId, ref: 'Bild'},

    unternehmensbereich: {type: Schema.Types.ObjectId, ref: 'Unternehmensbereich'},
    standort: {type: Schema.Types.ObjectId, ref: 'Standort'},
    ansprechpartner: {type: Schema.Types.ObjectId, ref: 'Ansprechpartner'},
}
);

// Virtual for Stellenangebot's URL
StellenangebotSchema
.virtual('url')
.get(function () {
  return '/stellenangebote/' + this._id;
});

StellenangebotSchema
.virtual('beginn_formatted')
.get(function () {
  return DateTime.fromJSDate(this.beginn).toLocaleString(DateTime.DATE_MED);
})

//Export model
module.exports = mongoose.model('Stellenangebot', StellenangebotSchema);