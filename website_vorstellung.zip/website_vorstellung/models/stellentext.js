var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var StellentextSchema = new Schema(
    {
        bezeichnung: {type: String, required: true},
        pfad: {type: String, required: true},
    }
);

// Virtual for Stellentexts URL
StellentextSchema
.virtual('url')
.get(function () {
    return '/stellenangebot/stellentext/' + this._id;
});

//Export model
module.exports = mongoose.model('Stellentext', StellentextSchema);